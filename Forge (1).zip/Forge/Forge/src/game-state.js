export const BUSINESS_OPTIONS = [
  {
    id: "food-production",
    name: "Food Production",
    icon: "✳",
    description: "Turn local ingredients into packaged food for your community.",
  },
  {
    id: "retail",
    name: "Retail",
    icon: "▦",
    description: "Bring useful everyday goods to the people around you.",
  },
  {
    id: "logistics",
    name: "Logistics",
    icon: "↗",
    description: "Help move packages and supplies between local businesses.",
  },
  {
    id: "manufacturing",
    name: "Manufacturing",
    icon: "⚙",
    description: "Make practical products that other businesses can use.",
  },
];

export function createStartingGameState() {
  return {
    cash: 10_000_000,
    day: 1,
    businessName: "Not established",
    businessType: null,
    employees: 0,
    revenue: 0,
    expenses: 0,
    profit: 0,
  };
}

export function selectBusiness(gameState, businessId) {
  const businessExists = BUSINESS_OPTIONS.some(
    (business) => business.id === businessId,
  );

  if (!gameState) {
    throw new Error("Start a new game before choosing a business.");
  }

  if (!businessExists) {
    throw new Error("Choose one of the available business types.");
  }

  return {
    ...gameState,
    businessType: businessId,
  };
}

export function canContinueToGame(gameState) {
  return Boolean(
    gameState &&
      BUSINESS_OPTIONS.some((business) => business.id === gameState.businessType),
  );
}
