import * as THREE from "three";

const ROAD_LENGTH = 78;
const ROAD_WIDTH = 11.2;

// Reuse box geometry so repeated street details don't allocate duplicate shapes.
const boxGeometryCache = new Map();

function getBoxGeometry(width, height, depth) {
  const key = `${width}:${height}:${depth}`;

  if (!boxGeometryCache.has(key)) {
    boxGeometryCache.set(key, new THREE.BoxGeometry(width, height, depth));
  }

  return boxGeometryCache.get(key);
}

function addBox(scene, size, position, material) {
  const mesh = new THREE.Mesh(
    getBoxGeometry(size.width, size.height, size.depth),
    material,
  );
  mesh.position.set(position.x, position.y, position.z);
  scene.add(mesh);
  return mesh;
}

function createMaterial(color, options = {}) {
  return new THREE.MeshStandardMaterial({
    color,
    roughness: 0.88,
    metalness: 0,
    ...options,
  });
}

function showWebGLNotice(sceneContainer, message) {
  sceneContainer.classList.add("webgl-unavailable");

  const notice = document.createElement("p");
  notice.className = "webgl-notice";
  notice.textContent = message;
  sceneContainer.replaceChildren(notice);
}

function createSignTexture(title, subtitle, accentColor) {
  const signCanvas = document.createElement("canvas");
  signCanvas.width = 512;
  signCanvas.height = 128;

  const context = signCanvas.getContext("2d");
  context.fillStyle = "#152d43";
  context.fillRect(0, 0, signCanvas.width, signCanvas.height);
  context.fillStyle = accentColor;
  context.fillRect(0, 0, 16, signCanvas.height);
  context.textAlign = "center";
  context.textBaseline = "middle";
  context.fillStyle = "#ffffff";
  context.font = "700 42px Arial, sans-serif";
  context.fillText(title, 264, 52, 450);
  context.fillStyle = "#c7d8e8";
  context.font = "500 18px Arial, sans-serif";
  context.fillText(subtitle, 264, 96, 450);

  const texture = new THREE.CanvasTexture(signCanvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return texture;
}

function addSign(scene, building, faceX, direction, material) {
  const sign = new THREE.Mesh(
    new THREE.PlaneGeometry(building.signWidth, 1.05),
    material,
  );
  sign.position.set(faceX + direction * 0.16, building.height - 0.9, building.z);
  sign.rotation.y = direction * (Math.PI / 2);
  scene.add(sign);
}

function addBuilding(scene, building, materials) {
  const { x, z, width, depth, height, direction, wallColor, accent, title, subtitle } =
    building;
  const frontX = x + direction * (width / 2);

  addBox(
    scene,
    { width, height, depth },
    { x, y: height / 2, z },
    createMaterial(wallColor),
  );

  // A low parapet gives the flat-roofed storefronts a finished silhouette.
  addBox(
    scene,
    { width: width + 0.45, height: 0.34, depth: depth + 0.45 },
    { x, y: height + 0.17, z },
    createMaterial(accent),
  );

  const facePositionX = frontX + direction * 0.1;
  const windowFrameMaterial = materials.windowFrame;
  const windowGlassMaterial = materials.windowGlass;
  const windowOffsets = [-depth * 0.29, depth * 0.29];

  for (const offset of windowOffsets) {
    const windowZ = z + offset;
    addBox(
      scene,
      { width: 0.2, height: 2.05, depth: 2.3 },
      { x: facePositionX, y: 2.05, z: windowZ },
      windowFrameMaterial,
    );
    addBox(
      scene,
      { width: 0.08, height: 1.78, depth: 2.03 },
      { x: facePositionX + direction * 0.13, y: 2.05, z: windowZ },
      windowGlassMaterial,
    );
  }

  // The central entrance and its small awning face the road.
  addBox(
    scene,
    { width: 0.22, height: 2.55, depth: 1.35 },
    { x: facePositionX, y: 1.34, z },
    materials.door,
  );
  addBox(
    scene,
    { width: 0.85, height: 0.18, depth: 2.45 },
    { x: frontX + direction * 0.52, y: 2.82, z },
    createMaterial(accent),
  );
  addBox(
    scene,
    { width: 1.15, height: 0.16, depth: 1.8 },
    { x: frontX + direction * 0.55, y: 0.12, z },
    materials.paving,
  );

  // A canvas-made sign is a Three.js texture; no image is downloaded.
  const signMaterial = new THREE.MeshBasicMaterial({
    map: createSignTexture(title, subtitle, accent),
  });
  addSign(scene, building, facePositionX, direction, signMaterial);
}

function addRoad(scene, materials) {
  addBox(
    scene,
    { width: ROAD_WIDTH, height: 0.12, depth: ROAD_LENGTH },
    { x: 0, y: -0.02, z: 0 },
    materials.asphalt,
  );

  // Raised sidewalks and curbs run along both sides of the road.
  for (const side of [-1, 1]) {
    addBox(
      scene,
      { width: 2.4, height: 0.2, depth: ROAD_LENGTH },
      { x: side * 6.95, y: 0.09, z: 0 },
      materials.sidewalk,
    );
    addBox(
      scene,
      { width: 0.26, height: 0.28, depth: ROAD_LENGTH },
      { x: side * 5.72, y: 0.14, z: 0 },
      materials.curb,
    );
    addBox(
      scene,
      { width: 0.13, height: 0.025, depth: ROAD_LENGTH - 2 },
      { x: side * 5.05, y: 0.052, z: 0 },
      materials.whiteLine,
    );
  }

  // Broken yellow center markings separate the two directions of traffic.
  const dashGeometry = getBoxGeometry(0.16, 0.03, 2.5);
  const dashCount = 24;
  const dashes = new THREE.InstancedMesh(
    dashGeometry,
    materials.yellowLine,
    dashCount,
  );
  const transform = new THREE.Object3D();

  for (let index = 0; index < dashCount; index += 1) {
    transform.position.set(0, 0.06, -35 + index * 3.05);
    transform.updateMatrix();
    dashes.setMatrixAt(index, transform.matrix);
  }

  scene.add(dashes);
}

function addTrees(scene) {
  const positions = [
    [-7.2, -29, 3.7],
    [-7.2, -14, 3.4],
    [-7.2, 14, 3.8],
    [-7.2, 29, 3.5],
    [7.2, -23, 3.6],
    [7.2, -4, 3.9],
    [7.2, 17, 3.5],
    [7.2, 31, 3.8],
  ];
  const trunkGeometry = new THREE.CylinderGeometry(0.18, 0.28, 3.5, 7);
  const crownGeometry = new THREE.IcosahedronGeometry(1.45, 1);
  const trunkMaterial = createMaterial("#80563c");
  const leafMaterials = [
    createMaterial("#4d8c54"),
    createMaterial("#5a995b"),
    createMaterial("#45814f"),
  ];
  const trunks = new THREE.InstancedMesh(
    trunkGeometry,
    trunkMaterial,
    positions.length,
  );
  const crowns = leafMaterials.map(
    (material) =>
      new THREE.InstancedMesh(crownGeometry, material, positions.length),
  );
  const transform = new THREE.Object3D();

  positions.forEach(([x, z, crownHeight], index) => {
    transform.rotation.set(0, 0, 0);
    transform.scale.set(1, 1, 1);
    transform.position.set(x, 1.75, z);
    transform.updateMatrix();
    trunks.setMatrixAt(index, transform.matrix);

    transform.position.set(x, crownHeight, z);
    transform.scale.setScalar(index % 2 === 0 ? 1 : 0.9);
    transform.updateMatrix();
    crowns[index % crowns.length].setMatrixAt(index, transform.matrix);
  });

  scene.add(trunks, ...crowns);
}

function addStreetlights(scene) {
  const positions = [-25, -8, 9, 26];
  const sides = [-1, 1];
  const lights = positions.flatMap((z) => sides.map((side) => [side, z]));
  const poleGeometry = new THREE.CylinderGeometry(0.07, 0.11, 4.4, 6);
  const armGeometry = getBoxGeometry(0.68, 0.1, 0.12);
  const headGeometry = getBoxGeometry(0.46, 0.16, 0.34);
  const poleMaterial = createMaterial("#536579", { metalness: 0.25 });
  const headMaterial = new THREE.MeshStandardMaterial({
    color: "#ffe0a0",
    emissive: "#735326",
    roughness: 0.55,
  });
  const poles = new THREE.InstancedMesh(poleGeometry, poleMaterial, lights.length);
  const arms = new THREE.InstancedMesh(armGeometry, poleMaterial, lights.length);
  const heads = new THREE.InstancedMesh(headGeometry, headMaterial, lights.length);
  const transform = new THREE.Object3D();

  lights.forEach(([side, z], index) => {
    const x = side * 7.75;

    transform.position.set(x, 2.3, z);
    transform.updateMatrix();
    poles.setMatrixAt(index, transform.matrix);

    transform.position.set(x - side * 0.28, 4.35, z);
    transform.rotation.z = side * Math.PI * 0.08;
    transform.updateMatrix();
    arms.setMatrixAt(index, transform.matrix);

    transform.rotation.set(0, 0, 0);
    transform.position.set(x - side * 0.55, 4.3, z);
    transform.updateMatrix();
    heads.setMatrixAt(index, transform.matrix);
  });

  scene.add(poles, arms, heads);
}

function addStreet(scene) {
  const ground = new THREE.Mesh(
    new THREE.PlaneGeometry(120, 110),
    createMaterial("#82a87e"),
  );
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.1;
  scene.add(ground);

  const materials = {
    asphalt: createMaterial("#46525e"),
    sidewalk: createMaterial("#c5bda9"),
    curb: createMaterial("#e0d7c4"),
    paving: createMaterial("#c9b99e"),
    whiteLine: createMaterial("#f4f0e6", { roughness: 0.7 }),
    yellowLine: createMaterial("#f2bd53", { roughness: 0.7 }),
    windowFrame: createMaterial("#243c50"),
    windowGlass: createMaterial("#75b8d0", {
      metalness: 0.12,
      roughness: 0.32,
    }),
    door: createMaterial("#79553a"),
  };

  addRoad(scene, materials);

  const buildings = [
    {
      x: -13,
      z: -1,
      width: 9,
      depth: 13,
      height: 7.2,
      direction: 1,
      wallColor: "#e6c89b",
      accent: "#d77b4e",
      title: "FORGE WORKS",
      subtitle: "YOUR NEXT BIG MOVE",
      signWidth: 5.6,
    },
    {
      x: -13,
      z: -20,
      width: 7,
      depth: 9,
      height: 4.9,
      direction: 1,
      wallColor: "#d9e0cf",
      accent: "#5b9c8c",
      title: "CORNER MARKET",
      subtitle: "DAILY GOODS",
      signWidth: 5.2,
    },
    {
      x: -13,
      z: 21,
      width: 7.5,
      depth: 10,
      height: 5.4,
      direction: 1,
      wallColor: "#e2c1ac",
      accent: "#c56d59",
      title: "MANGO HOUSE",
      subtitle: "FRESH & LOCAL",
      signWidth: 5.2,
    },
    {
      x: 13,
      z: -19,
      width: 7.5,
      depth: 10,
      height: 5.2,
      direction: -1,
      wallColor: "#cbd8dc",
      accent: "#54859a",
      title: "MAKER STUDIO",
      subtitle: "IDEAS IN MOTION",
      signWidth: 5.2,
    },
    {
      x: 13,
      z: 20,
      width: 7,
      depth: 9,
      height: 4.8,
      direction: -1,
      wallColor: "#e5d3a4",
      accent: "#bb9150",
      title: "SUNRISE CAFE",
      subtitle: "A GOOD PLACE TO START",
      signWidth: 5.1,
    },
  ];

  for (const building of buildings) {
    addBuilding(scene, building, materials);
  }

  addTrees(scene);
  addStreetlights(scene);
}

export function createStreetScene(canvas) {
  const sceneContainer = canvas.parentElement;
  let renderer;

  try {
    const context = canvas.getContext("webgl2", {
      alpha: false,
      antialias: false,
      powerPreference: "low-power",
    });

    if (!context) {
      throw new Error("WebGL 2 is unavailable in this browser.");
    }

    renderer = new THREE.WebGLRenderer({
      canvas,
      context,
      antialias: false,
    });
  } catch (error) {
    showWebGLNotice(
      sceneContainer,
      "3D graphics are not available in this browser preview. Open FORGE in a browser with WebGL 2 enabled to explore the street.",
    );
    console.warn("FORGE could not start its 3D renderer:", error.message);
    return;
  }

  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 1.5));
  renderer.outputColorSpace = THREE.SRGBColorSpace;

  const scene = new THREE.Scene();
  scene.background = new THREE.Color("#b7d0da");
  scene.fog = new THREE.Fog("#b7d0da", 70, 125);

  const camera = new THREE.PerspectiveCamera(43, 1, 0.1, 150);
  camera.position.set(25, 22, 29);

  const target = new THREE.Vector3(0, 0, 0);
  const orbit = new THREE.Spherical().setFromVector3(
    camera.position.clone().sub(target),
  );
  const temporaryPosition = new THREE.Vector3();

  scene.add(new THREE.HemisphereLight("#e1f2ff", "#76694e", 2.2));
  const sunlight = new THREE.DirectionalLight("#fff3d8", 2.3);
  sunlight.position.set(-18, 28, 14);
  scene.add(sunlight);

  addStreet(scene);

  function render() {
    renderer.render(scene, camera);
  }

  function updateCamera() {
    temporaryPosition.setFromSpherical(orbit).add(target);
    camera.position.copy(temporaryPosition);
    camera.lookAt(target);
    render();
  }

  function resizeRenderer() {
    const width = Math.max(sceneContainer.clientWidth, 1);
    const height = Math.max(sceneContainer.clientHeight, 1);

    camera.aspect = width / height;
    camera.updateProjectionMatrix();
    renderer.setSize(width, height, false);
    render();
  }

  let isDragging = false;
  let previousPointerX = 0;
  let previousPointerY = 0;

  canvas.addEventListener("pointerdown", (event) => {
    isDragging = true;
    previousPointerX = event.clientX;
    previousPointerY = event.clientY;
    canvas.classList.add("is-dragging");
    canvas.setPointerCapture(event.pointerId);
  });

  canvas.addEventListener("pointermove", (event) => {
    if (!isDragging) return;

    const deltaX = event.clientX - previousPointerX;
    const deltaY = event.clientY - previousPointerY;
    previousPointerX = event.clientX;
    previousPointerY = event.clientY;

    orbit.theta -= deltaX * 0.006;
    orbit.phi = THREE.MathUtils.clamp(orbit.phi - deltaY * 0.006, 0.25, 1.42);
    updateCamera();
  });

  function stopDragging(event) {
    isDragging = false;
    canvas.classList.remove("is-dragging");

    if (canvas.hasPointerCapture(event.pointerId)) {
      canvas.releasePointerCapture(event.pointerId);
    }
  }

  canvas.addEventListener("pointerup", stopDragging);
  canvas.addEventListener("pointercancel", stopDragging);

  canvas.addEventListener(
    "wheel",
    (event) => {
      event.preventDefault();
      orbit.radius = THREE.MathUtils.clamp(
        orbit.radius * Math.exp(event.deltaY * 0.001),
        23,
        72,
      );
      updateCamera();
    },
    { passive: false },
  );

  window.addEventListener("resize", resizeRenderer);
  const resizeObserver = new ResizeObserver(resizeRenderer);
  resizeObserver.observe(sceneContainer);

  resizeRenderer();
  updateCamera();
}
