import "../style.css";
import { createStreetScene } from "./street-scene.js";
import { BUSINESS_OPTIONS } from "./game-state.js";
import { GameSession } from "./game-session.js";

const session = new GameSession();
const screens = {
  welcome: document.querySelector("#welcome-screen"),
  signup: document.querySelector("#signup-screen"),
  login: document.querySelector("#login-screen"),
  selection: document.querySelector("#selection-screen"),
  game: document.querySelector("#game-screen"),
};
const businessGrid = document.querySelector("#business-options");
const continueButton = document.querySelector("#continue-game");
const selectionStatus = document.querySelector("#selection-status");
const sceneCanvas = document.querySelector("#forge-scene");

let streetSceneStarted = false;
let visibleScreen = session.currentScreen;
let returnScreenAfterAuth = "welcome";

function showScreen(screenName) {
  for (const [name, screen] of Object.entries(screens)) {
    screen.hidden = name !== screenName;
  }
  visibleScreen = screenName;
}

function openAuthScreen(screenName) {
  if (visibleScreen !== "signup" && visibleScreen !== "login") {
    returnScreenAfterAuth = visibleScreen;
  }
  showScreen(screenName);
}

function returnFromAuthScreen() {
  showScreen(returnScreenAfterAuth);
}

function showFormMessage(element, message, tone = "error") {
  element.textContent = message;
  element.dataset.tone = tone;
}

function findInvalidControl(form) {
  return form.querySelector(":invalid");
}

function findBusiness(businessId) {
  return BUSINESS_OPTIONS.find((business) => business.id === businessId);
}

function updateBusinessCards() {
  for (const button of businessGrid.querySelectorAll("[data-business]")) {
    const isSelected = button.dataset.business === session.gameState?.businessType;
    button.classList.toggle("is-selected", isSelected);
    button.setAttribute("aria-pressed", String(isSelected));
  }

  continueButton.disabled = !session.gameState?.businessType;
}

function updateSelectionStatus() {
  const selectedBusiness = findBusiness(session.gameState?.businessType);
  selectionStatus.textContent = selectedBusiness
    ? `${selectedBusiness.name} selected. Continue when you are ready.`
    : "Choose a business to continue.";
}

function renderGameState() {
  const gameState = session.gameState;
  const selectedBusiness = findBusiness(gameState.businessType);
  const naira = new Intl.NumberFormat("en-NG", {
    style: "currency",
    currency: "NGN",
    maximumFractionDigits: 0,
  });

  document.querySelector("#game-business-type").textContent =
    selectedBusiness?.name ?? "Business not selected";
  document.querySelector("#game-business-name").textContent =
    gameState.businessName;
  document.querySelector("#stat-cash").textContent = naira.format(gameState.cash);
  document.querySelector("#stat-day").textContent = String(gameState.day);
  document.querySelector("#stat-employees").textContent = String(
    gameState.employees,
  );
  document.querySelector("#stat-revenue").textContent = naira.format(
    gameState.revenue,
  );
  document.querySelector("#stat-expenses").textContent = naira.format(
    gameState.expenses,
  );
  document.querySelector("#stat-profit").textContent = naira.format(
    gameState.profit,
  );
}

function startStreetSceneOnce() {
  if (streetSceneStarted) return;

  streetSceneStarted = true;
  createStreetScene(sceneCanvas);
}

for (const business of BUSINESS_OPTIONS) {
  const card = document.createElement("button");
  card.className = "business-card";
  card.type = "button";
  card.dataset.business = business.id;
  card.setAttribute("aria-pressed", "false");

  const icon = document.createElement("span");
  icon.className = "business-card-icon";
  icon.setAttribute("aria-hidden", "true");
  icon.textContent = business.icon;

  const name = document.createElement("strong");
  name.textContent = business.name;

  const description = document.createElement("span");
  description.className = "business-card-description";
  description.textContent = business.description;

  card.append(icon, name, description);
  businessGrid.append(card);
}

document.querySelector("#start-game").addEventListener("click", () => {
  session.startNewGame();
  updateBusinessCards();
  updateSelectionStatus();
  showScreen(session.currentScreen);
});

document.querySelector("#open-signup").addEventListener("click", () => {
  openAuthScreen("signup");
});

document.querySelector("#open-login").addEventListener("click", () => {
  openAuthScreen("login");
});

document.querySelector("#game-login").addEventListener("click", () => {
  openAuthScreen("login");
});

document.querySelector("#signup-back").addEventListener("click", returnFromAuthScreen);
document.querySelector("#login-back").addEventListener("click", returnFromAuthScreen);
document.querySelector("#signup-to-login").addEventListener("click", () => {
  openAuthScreen("login");
});
document.querySelector("#login-to-signup").addEventListener("click", () => {
  openAuthScreen("signup");
});

const signupForm = document.querySelector("#signup-form");
const signupStatus = document.querySelector("#signup-status");
const signupPassword = document.querySelector("#signup-password");
const confirmPassword = document.querySelector("#confirm-password");

signupForm.addEventListener("input", () => {
  const passwordsMatch = signupPassword.value === confirmPassword.value;
  confirmPassword.setCustomValidity(
    passwordsMatch ? "" : "Passwords do not match.",
  );
  signupStatus.textContent = "";
  delete signupStatus.dataset.tone;
});

signupForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const invalidControl = findInvalidControl(signupForm);

  if (invalidControl) {
    showFormMessage(signupStatus, invalidControl.validationMessage);
    invalidControl.focus();
    return;
  }

  // No account is created until a real authentication service is configured.
  signupPassword.value = "";
  confirmPassword.value = "";
  showFormMessage(
    signupStatus,
    "Authentication is not connected. No account was created and your details were not sent or saved.",
    "notice",
  );
});

const loginForm = document.querySelector("#login-form");
const loginStatus = document.querySelector("#login-status");
const loginPassword = document.querySelector("#login-password");

loginForm.addEventListener("input", () => {
  loginStatus.textContent = "";
  delete loginStatus.dataset.tone;
});

loginForm.addEventListener("submit", (event) => {
  event.preventDefault();
  const invalidControl = findInvalidControl(loginForm);

  if (invalidControl) {
    showFormMessage(loginStatus, invalidControl.validationMessage);
    invalidControl.focus();
    return;
  }

  // Credentials are deliberately not sent or saved by this interface prototype.
  loginPassword.value = "";
  showFormMessage(
    loginStatus,
    "Authentication is not connected. No sign-in was attempted and your password was not sent or saved.",
    "notice",
  );
});

businessGrid.addEventListener("click", (event) => {
  const card = event.target.closest("[data-business]");
  if (!card || !businessGrid.contains(card)) return;

  if (session.chooseBusiness(card.dataset.business)) {
    updateBusinessCards();
    updateSelectionStatus();
  }
});

continueButton.addEventListener("click", () => {
  if (!session.continueToGame()) {
    updateSelectionStatus();
    return;
  }

  showScreen(session.currentScreen);
  renderGameState();
  startStreetSceneOnce();
});

document.querySelector("#back-to-selection").addEventListener("click", () => {
  if (!session.returnToBusinessSelection()) return;

  updateBusinessCards();
  updateSelectionStatus();
  showScreen(session.currentScreen);
});

document.querySelector("#restart-game").addEventListener("click", () => {
  const confirmed = window.confirm(
    "Restart FORGE? Your current game session will be cleared.",
  );

  if (!session.restart(confirmed)) return;

  updateBusinessCards();
  updateSelectionStatus();
  showScreen(session.currentScreen);
});

showScreen(session.currentScreen);
