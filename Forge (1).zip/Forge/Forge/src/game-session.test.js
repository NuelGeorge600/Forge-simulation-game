import test from "node:test";
import assert from "node:assert/strict";
import {
  BUSINESS_OPTIONS,
  canContinueToGame,
  createStartingGameState,
  selectBusiness,
} from "./game-state.js";
import { GameSession } from "./game-session.js";

test("a new game starts with the requested values", () => {
  assert.deepEqual(createStartingGameState(), {
    cash: 10_000_000,
    day: 1,
    businessName: "Not established",
    businessType: null,
    employees: 0,
    revenue: 0,
    expenses: 0,
    profit: 0,
  });
});

test("each offered business can be recorded in the state", () => {
  const startingState = createStartingGameState();

  for (const business of BUSINESS_OPTIONS) {
    const selectedState = selectBusiness(startingState, business.id);
    assert.equal(selectedState.businessType, business.id);
    assert.equal(selectedState.cash, startingState.cash);
  }

  assert.equal(startingState.businessType, null);
});

test("unknown businesses cannot be selected", () => {
  assert.throws(() => selectBusiness(createStartingGameState(), "airline"));
  assert.throws(() => selectBusiness(null, "retail"));
});

test("the game cannot continue until a business is selected", () => {
  const session = new GameSession();
  session.startNewGame();

  assert.equal(canContinueToGame(session.gameState), false);
  assert.equal(session.continueToGame(), false);
  assert.equal(session.currentScreen, "selection");
});

test("selecting a business allows the player to enter the game", () => {
  const session = new GameSession();
  session.startNewGame();

  assert.equal(session.chooseBusiness("logistics"), true);
  assert.equal(session.continueToGame(), true);
  assert.equal(session.currentScreen, "game");
  assert.equal(session.gameState.businessType, "logistics");
});

test("returning to selection preserves the current game session", () => {
  const session = new GameSession();
  session.startNewGame();
  session.chooseBusiness("retail");
  session.continueToGame();
  const stateBeforeReturning = session.gameState;

  assert.equal(session.returnToBusinessSelection(), true);
  assert.equal(session.currentScreen, "selection");
  assert.equal(session.gameState, stateBeforeReturning);
  assert.equal(session.gameState.businessType, "retail");
  assert.equal(session.gameState.cash, 10_000_000);
});

test("restart leaves the session intact until confirmation", () => {
  const session = new GameSession();
  session.startNewGame();
  session.chooseBusiness("manufacturing");
  session.continueToGame();
  const stateBeforeRestart = session.gameState;

  assert.equal(session.restart(false), false);
  assert.equal(session.currentScreen, "game");
  assert.equal(session.gameState, stateBeforeRestart);

  assert.equal(session.restart(true), true);
  assert.equal(session.currentScreen, "welcome");
  assert.equal(session.gameState, null);
});
