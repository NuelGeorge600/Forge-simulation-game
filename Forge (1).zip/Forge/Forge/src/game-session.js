import {
  canContinueToGame,
  createStartingGameState,
  selectBusiness,
} from "./game-state.js";

// This object owns navigation and player state, not the Three.js scene.
export class GameSession {
  constructor() {
    this.gameState = null;
    this.currentScreen = "welcome";
  }

  startNewGame() {
    this.gameState = createStartingGameState();
    this.currentScreen = "selection";
  }

  chooseBusiness(businessId) {
    if (this.currentScreen !== "selection" || !this.gameState) {
      return false;
    }

    try {
      this.gameState = selectBusiness(this.gameState, businessId);
      return true;
    } catch {
      return false;
    }
  }

  continueToGame() {
    if (
      this.currentScreen !== "selection" ||
      !canContinueToGame(this.gameState)
    ) {
      return false;
    }

    this.currentScreen = "game";
    return true;
  }

  returnToBusinessSelection() {
    if (this.currentScreen !== "game") {
      return false;
    }

    // Keep the same gameState object so returning here never discards progress.
    this.currentScreen = "selection";
    return true;
  }

  restart(confirmed) {
    if (!confirmed) {
      return false;
    }

    this.gameState = null;
    this.currentScreen = "welcome";
    return true;
  }
}
